export enum MapDoodleEnum {
    PIN = 'pin',
    POLYLINE = 'polyline',
    POLYGON = 'polygon',
    Close = 'off'
}
