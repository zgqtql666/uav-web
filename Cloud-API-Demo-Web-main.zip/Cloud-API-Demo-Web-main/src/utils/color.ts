export const commonColor = {
  WARN: '#FF9900', // 黄色
  FAIL: '#E02020', // 红色
  WHITE: '#FFFFFF', // 白色
  NORMAL: '#19BE6B', // 绿色
  BLUE: '#2B85E4', // 蓝色
  PINK: '#F7C0BA', // 粉
}
