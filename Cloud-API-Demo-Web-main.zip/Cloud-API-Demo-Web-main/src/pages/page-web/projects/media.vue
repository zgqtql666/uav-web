<template>
  <div class="project-media-wrapper">
  </div>
</template>

<script lang="ts" setup>
</script>

<style lang="scss" scoped>
</style>
