package com.dji.sample.wayline.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dji.sample.wayline.model.entity.WaylineFileEntity;

/**
 * @author sean
 * @version 0.3
 * @date 2021/12/22
 */
public interface IWaylineFileMapper extends BaseMapper<WaylineFileEntity> {
}
