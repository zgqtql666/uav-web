package com.dji.sample.manage.model.common;

import lombok.Data;

/**
 * @author sean
 * @version 1.1
 * @date 2022/7/7
 */
@Data
public class HmsMessage {

    private String zh;

    private String en;
}
