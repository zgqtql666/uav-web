package com.dji.sample.component.mqtt.model;

/**
 * @author sean
 * @version 1.1
 * @date 2022/6/14
 */
public final class MapKeyConst {

    private MapKeyConst(){

    }

    public static final String ACL = "acl";

}
