package com.dji.sample.manage.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dji.sample.manage.model.entity.UserEntity;

public interface IUserMapper extends BaseMapper<UserEntity> {

}
