package com.dji.sample.manage.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dji.sample.manage.model.entity.LogsFileIndexEntity;

/**
 * @author sean
 * @version 1.2
 * @date 2022/9/8
 */
public interface ILogsFileIndexMapper extends BaseMapper<LogsFileIndexEntity> {
}
