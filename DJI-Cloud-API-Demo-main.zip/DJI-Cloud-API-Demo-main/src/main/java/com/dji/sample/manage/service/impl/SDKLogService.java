package com.dji.sample.manage.service.impl;

import com.dji.sdk.cloudapi.log.api.AbstractLogService;
import org.springframework.stereotype.Service;

/**
 * @author sean
 * @version 1.7
 * @date 2023/7/6
 */
@Service
public class SDKLogService extends AbstractLogService {

}
