package com.dji.sample.manage.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dji.sample.manage.model.entity.WorkspaceEntity;

public interface IWorkspaceMapper extends BaseMapper<WorkspaceEntity> {

}
