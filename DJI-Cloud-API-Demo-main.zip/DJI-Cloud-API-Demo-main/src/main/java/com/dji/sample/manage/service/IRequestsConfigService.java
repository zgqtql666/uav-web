package com.dji.sample.manage.service;

/**
 * @author sean
 * @version 1.3
 * @date 2022/11/10
 */
public interface IRequestsConfigService {

    /**
     * Get the parameters required by config method.
     * @return
     */
    Object getConfig();
}
