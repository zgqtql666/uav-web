package com.dji.sdk.cloudapi.device;

/**
 * @author sean
 * @version 1.7
 * @date 2023/5/29
 */
public enum DeviceModelEnum {

    RC, DOCK, DRONE;
}
